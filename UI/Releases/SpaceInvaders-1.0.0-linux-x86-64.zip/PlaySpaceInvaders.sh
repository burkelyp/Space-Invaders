#!/bin/bash

# Absolute path to your app's root
APPDIR="./linux-build"


# Qt 6.9 location
export QT_QPA_PLATFORM_PLUGIN_PATH="platform"

# Dependendencies location
export LD_LIBRARY_PATH="lib"
# export DESTDIR="$APPDIR/lib"

# Optional: tell Qt to use xcb (if not default)
export QT_QPA_PLATFORM=xcb

# Run the app
cd "$APPDIR"
./SpaceInvadersUI
